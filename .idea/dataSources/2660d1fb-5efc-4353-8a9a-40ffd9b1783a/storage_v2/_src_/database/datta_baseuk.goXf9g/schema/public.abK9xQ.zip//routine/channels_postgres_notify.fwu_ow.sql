create function channels_postgres_notify() returns trigger
    language plpgsql
as
$$
            DECLARE
            BEGIN
                PERFORM pg_notify(NEW.channel, NEW.id::text);
                RETURN NEW;
            END;
        $$;

alter function channels_postgres_notify() owner to postgres;

